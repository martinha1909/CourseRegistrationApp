Group Members:
Duan Le - duan.le1@ucalgary.ca
Vu Ha - vu.ha1@ucalgary.ca
Ayush Chaudhari - ayush.chaudhari@ucalgary.ca

Running instructions:
1. Create a schemaon MySQL Workbench called mydb.
2. Run the DBSetup.class to setup all the databases.
3. Run the ServerCommunication.class to start the server.
4. Run the ClientCommunication.class to start the client.

No bonus features.