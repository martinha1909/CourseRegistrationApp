package server.model;

public interface DBCredentials {
	
    static final String DB_URL = "jdbc:mysql://localhost/mydb"; //name your schema mydb

    //Database credentials
    static final String USERNAME = "root";
    static final String PASSWORD = "ensf409";
}